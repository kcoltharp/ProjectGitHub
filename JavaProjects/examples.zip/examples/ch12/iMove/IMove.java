
public interface IMove 
{
   /** Move this object. */
   public void move();
}
