
public class GoodsLineItem extends LineItem 
{
   public GoodsLineItem(int aQuantity, String aDescr, double aUnitCost)
   {  super(aQuantity, aDescr, aUnitCost);
   }
}
