
public class Item extends Object
{
	private String description;
	
	public Item(String descr)
	{	super();
		this.description = descr;
	}
	
	public String toString()
	{	return this.description;
	}
}
