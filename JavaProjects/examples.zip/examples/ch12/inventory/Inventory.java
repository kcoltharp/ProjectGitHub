import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import becker.util.Test;


/** A class using an interface to promote flexibility.
 *
 *  @author Byron Weber Becker */
public class Inventory extends Object
{	
	private List<Item> inventory = new ArrayList<Item>();
	private List<Item> reorder = new LinkedList<Item>();
	
	/** Remove the specified items from the current inventory.  Update the list of items
	 *  to reorder. 
	 *  @itemsSold The items that have been sold and need to be removed from inventory. */
	public void removeInventory(List<Item> itemsSold)
	{	for(Item item : itemsSold)
		{	this.inventory.remove(item);
			
			// If it's the last one and not already on the reorder list, add it
			if (!this.inventory.contains(item) &&
						!this.reorder.contains(item))
			{	this.reorder.add(item);
			}
		}
	}
	
	
	public static void main(String[] args)
	{
		Inventory inv = new Inventory();
		inv.inventory.add(new Item("Soup"));
		inv.inventory.add(new Item("Soup"));
		inv.inventory.add(new Item("Carrots"));
		
		List<Item> sales = new ArrayList<Item>();
		sales.add(new Item("Soup"));
		inv.removeInventory(sales);
		
		Test.ckEquals("reorder list", "[Soup]", inv.reorder.toString());
	}
}
