
/** An enumeration of the genders used in the Person class.
* 
* @author Byron Weber Becker */
public enum Gender
{	MALE, FEMALE 
}
