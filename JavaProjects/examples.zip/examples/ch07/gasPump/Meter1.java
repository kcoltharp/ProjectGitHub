
public class Meter1 extends Object
{
   public Meter1()
   {  super();
   }	
	
   public static void main(String[] args)
   {  Meter1 m = new Meter1();
   }

}
