

/** Each person in the BigBroBigSis database has a distict role as either
 * a "big" or a "little".
 *
 * @author Byron Weber Becker */
public enum Role 
{
   BIG, LITTLE;}
