'Program Name:      Payroll Calculator
'Developer:         Professor Carman
'Date:              September 16, 2014
'This program will allow the user to enter their name, hours worked and pay per hour.  Then the program will
'calculate how much their gross pay, net pay and total tax amount.  This program also performs input validation
'so that if errors are made on entry, the program will give an appropriate error message.

Option Strict On
Public Class frmPayrollCalculator

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        'Constant Declarations
        Const cnumSingleRate As Decimal = 0.18D
        Const cnumFamilyRate As Decimal = 0.15D
        Const cnumHourlyRateTop As Integer = 40
        Const cnumHourlyRateLower As Integer = 8
        Const cnumHoursWorkedTop As Integer = 60
        Const cnumHoursWorkedLower As Integer = 5
        'Variable Declarations
        Dim userName As String
        Dim hoursWorked As Decimal
        Dim payPerHour As Decimal
        Dim taxRate As Decimal
        Dim taxAmount As Decimal
        Dim grossPay As Decimal
        Dim netPay As Decimal

        If Not (txtName.Text = "") And IsNumeric(txtHoursWorked.Text) And IsNumeric(txtPayPerHour.Text) Then
            'This will take the data from the text box and place it into a variable
            userName = txtName.Text
            hoursWorked = Convert.ToInt32(txtHoursWorked.Text)
            payPerHour = Convert.ToDecimal(txtPayPerHour.Text)
            'This selection structure will check to see if the entered values fall within ranges
            If hoursWorked >= cnumHoursWorkedLower And payPerHour >= cnumHourlyRateLower And
                payPerHour <= cnumHourlyRateTop And hoursWorked <= cnumHoursWorkedTop Then
                'This will set the tax rate by which radio button is checked
                If radSingleRate.Checked Then
                    taxRate = cnumSingleRate
                ElseIf radFamilyRate.Checked Then
                    taxRate = cnumFamilyRate
                End If
                'These will perform the calculations
                grossPay = (hoursWorked * payPerHour)
                taxAmount = grossPay * taxRate
                netPay = grossPay - taxRate
                'These will output the information to the labels
                lblGrossPayTotal.Text = grossPay.ToString("C")
                lblTaxResult.Text = taxRate.ToString("C")
                lblNetResult.Text = netPay.ToString("C")
                lblNameResult.Text = userName
            Else
                If hoursWorked < cnumHoursWorkedLower Then
                    MsgBox("Please enter valid Hours Worked more than $5.", , "Input Error")
                End If
                If hoursWorked > cnumHoursWorkedTop Then
                    MsgBox("Please enter valid Hours Worked less than 60.", , "Input Error")
                End If
                If payPerHour < cnumHourlyRateLower Then
                    MsgBox("Please enter valid Pay Per Hour over $8.", , "Input Error")
                End If
                If payPerHour > cnumHourlyRateTop Then
                    MsgBox("Please enter a valid Pay Per Hour Less than $40.", , "Input Error")
                End If

            End If

        Else
            MsgBox("Incorrect Entry Detected, please make sure all items are entered correctly")
        End If

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        'Clears the appropriate text boxes and labels, and set the radio button
        txtName.Text = ""
        txtHoursWorked.Text = ""
        txtPayPerHour.Text = ""
        radSingleRate.Checked = True
        radFamilyRate.Checked = False
        txtName.Focus()
        lblGrossPayTotal.Text = ""
        lblTaxResult.Text = ""
        lblNetResult.Text = ""
        lblNameResult.Text = ""
    End Sub

    Private Sub frmPayroll_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtName.Focus()
        lblGrossPayTotal.Text = ""
    End Sub

    Private Sub frmPayrollCalculator_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Clears label boxes on Form Load
        lblGrossPayTotal.Text = ""
        lblTaxResult.Text = ""
        lblNetResult.Text = ""
        lblNameResult.Text = ""
    End Sub
End Class
