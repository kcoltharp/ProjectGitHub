<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayrollCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblName = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblHoursWorked = New System.Windows.Forms.Label()
        Me.lblPayPerHour = New System.Windows.Forms.Label()
        Me.txtHoursWorked = New System.Windows.Forms.TextBox()
        Me.txtPayPerHour = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.radFamilyRate = New System.Windows.Forms.RadioButton()
        Me.radSingleRate = New System.Windows.Forms.RadioButton()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblGrossPay = New System.Windows.Forms.Label()
        Me.lblGrossPayTotal = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblNet = New System.Windows.Forms.Label()
        Me.lblTaxResult = New System.Windows.Forms.Label()
        Me.lblNetResult = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTheName = New System.Windows.Forms.Label()
        Me.lblNameResult = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(127, 130)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(54, 19)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name:"
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(261, 127)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(143, 26)
        Me.txtName.TabIndex = 1
        '
        'lblHoursWorked
        '
        Me.lblHoursWorked.AutoSize = True
        Me.lblHoursWorked.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHoursWorked.Location = New System.Drawing.Point(127, 172)
        Me.lblHoursWorked.Name = "lblHoursWorked"
        Me.lblHoursWorked.Size = New System.Drawing.Size(113, 19)
        Me.lblHoursWorked.TabIndex = 2
        Me.lblHoursWorked.Text = "Hours Worked:"
        '
        'lblPayPerHour
        '
        Me.lblPayPerHour.AutoSize = True
        Me.lblPayPerHour.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPayPerHour.Location = New System.Drawing.Point(127, 214)
        Me.lblPayPerHour.Name = "lblPayPerHour"
        Me.lblPayPerHour.Size = New System.Drawing.Size(103, 19)
        Me.lblPayPerHour.TabIndex = 3
        Me.lblPayPerHour.Text = "Pay Per Hour:"
        '
        'txtHoursWorked
        '
        Me.txtHoursWorked.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtHoursWorked.Location = New System.Drawing.Point(261, 169)
        Me.txtHoursWorked.Name = "txtHoursWorked"
        Me.txtHoursWorked.Size = New System.Drawing.Size(40, 26)
        Me.txtHoursWorked.TabIndex = 4
        Me.txtHoursWorked.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPayPerHour
        '
        Me.txtPayPerHour.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPayPerHour.Location = New System.Drawing.Point(261, 211)
        Me.txtPayPerHour.Name = "txtPayPerHour"
        Me.txtPayPerHour.Size = New System.Drawing.Size(47, 26)
        Me.txtPayPerHour.TabIndex = 5
        Me.txtPayPerHour.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Goldenrod
        Me.Panel1.Controls.Add(Me.radFamilyRate)
        Me.Panel1.Controls.Add(Me.radSingleRate)
        Me.Panel1.Location = New System.Drawing.Point(168, 255)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(133, 93)
        Me.Panel1.TabIndex = 6
        '
        'radFamilyRate
        '
        Me.radFamilyRate.AutoSize = True
        Me.radFamilyRate.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radFamilyRate.Location = New System.Drawing.Point(17, 53)
        Me.radFamilyRate.Name = "radFamilyRate"
        Me.radFamilyRate.Size = New System.Drawing.Size(108, 23)
        Me.radFamilyRate.TabIndex = 1
        Me.radFamilyRate.Text = "Family Rate"
        Me.radFamilyRate.UseVisualStyleBackColor = True
        '
        'radSingleRate
        '
        Me.radSingleRate.AutoSize = True
        Me.radSingleRate.Checked = True
        Me.radSingleRate.Font = New System.Drawing.Font("Gisha", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radSingleRate.Location = New System.Drawing.Point(17, 12)
        Me.radSingleRate.Name = "radSingleRate"
        Me.radSingleRate.Size = New System.Drawing.Size(105, 23)
        Me.radSingleRate.TabIndex = 0
        Me.radSingleRate.TabStop = True
        Me.radSingleRate.Text = "Single Rate"
        Me.radSingleRate.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(46, 372)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(92, 23)
        Me.btnCalculate.TabIndex = 7
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(197, 372)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(92, 23)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Lucida Sans", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(179, 54)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(250, 32)
        Me.lblHeading.TabIndex = 9
        Me.lblHeading.Text = "Payroll Calculator"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.PayrollCalculator.My.Resources.Resources.payroll_processing
        Me.PictureBox1.Location = New System.Drawing.Point(25, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(135, 106)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'lblGrossPay
        '
        Me.lblGrossPay.AutoSize = True
        Me.lblGrossPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrossPay.Location = New System.Drawing.Point(21, 410)
        Me.lblGrossPay.Name = "lblGrossPay"
        Me.lblGrossPay.Size = New System.Drawing.Size(86, 20)
        Me.lblGrossPay.TabIndex = 11
        Me.lblGrossPay.Text = "Gross Pay:"
        '
        'lblGrossPayTotal
        '
        Me.lblGrossPayTotal.AutoSize = True
        Me.lblGrossPayTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrossPayTotal.Location = New System.Drawing.Point(102, 410)
        Me.lblGrossPayTotal.Name = "lblGrossPayTotal"
        Me.lblGrossPayTotal.Size = New System.Drawing.Size(58, 20)
        Me.lblGrossPayTotal.TabIndex = 12
        Me.lblGrossPayTotal.Text = "888.88"
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTax.Location = New System.Drawing.Point(192, 410)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(38, 20)
        Me.lblTax.TabIndex = 13
        Me.lblTax.Text = "Tax:"
        '
        'lblNet
        '
        Me.lblNet.AutoSize = True
        Me.lblNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNet.Location = New System.Drawing.Point(307, 410)
        Me.lblNet.Name = "lblNet"
        Me.lblNet.Size = New System.Drawing.Size(68, 20)
        Me.lblNet.TabIndex = 14
        Me.lblNet.Text = "Net Pay:"
        '
        'lblTaxResult
        '
        Me.lblTaxResult.AutoSize = True
        Me.lblTaxResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTaxResult.Location = New System.Drawing.Point(232, 410)
        Me.lblTaxResult.Name = "lblTaxResult"
        Me.lblTaxResult.Size = New System.Drawing.Size(58, 20)
        Me.lblTaxResult.TabIndex = 15
        Me.lblTaxResult.Text = "888.88"
        '
        'lblNetResult
        '
        Me.lblNetResult.AutoSize = True
        Me.lblNetResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNetResult.Location = New System.Drawing.Point(371, 410)
        Me.lblNetResult.Name = "lblNetResult"
        Me.lblNetResult.Size = New System.Drawing.Size(58, 20)
        Me.lblNetResult.TabIndex = 16
        Me.lblNetResult.Text = "888.88"
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(348, 371)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 17
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTheName
        '
        Me.lblTheName.AutoSize = True
        Me.lblTheName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTheName.Location = New System.Drawing.Point(97, 437)
        Me.lblTheName.Name = "lblTheName"
        Me.lblTheName.Size = New System.Drawing.Size(55, 20)
        Me.lblTheName.TabIndex = 18
        Me.lblTheName.Text = "Name:"
        '
        'lblNameResult
        '
        Me.lblNameResult.AutoSize = True
        Me.lblNameResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameResult.Location = New System.Drawing.Point(158, 437)
        Me.lblNameResult.Name = "lblNameResult"
        Me.lblNameResult.Size = New System.Drawing.Size(213, 20)
        Me.lblNameResult.TabIndex = 19
        Me.lblNameResult.Text = "Name Will Eventually go here"
        '
        'frmPayrollCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.ClientSize = New System.Drawing.Size(469, 466)
        Me.Controls.Add(Me.lblNameResult)
        Me.Controls.Add(Me.lblTheName)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblNetResult)
        Me.Controls.Add(Me.lblTaxResult)
        Me.Controls.Add(Me.lblNet)
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.lblGrossPayTotal)
        Me.Controls.Add(Me.lblGrossPay)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txtPayPerHour)
        Me.Controls.Add(Me.txtHoursWorked)
        Me.Controls.Add(Me.lblPayPerHour)
        Me.Controls.Add(Me.lblHoursWorked)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblName)
        Me.Name = "frmPayrollCalculator"
        Me.Text = "Payroll Calculator"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents lblHoursWorked As System.Windows.Forms.Label
    Friend WithEvents lblPayPerHour As System.Windows.Forms.Label
    Friend WithEvents txtHoursWorked As System.Windows.Forms.TextBox
    Friend WithEvents txtPayPerHour As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents radFamilyRate As System.Windows.Forms.RadioButton
    Friend WithEvents radSingleRate As System.Windows.Forms.RadioButton
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblGrossPay As System.Windows.Forms.Label
    Friend WithEvents lblGrossPayTotal As System.Windows.Forms.Label
    Friend WithEvents lblTax As System.Windows.Forms.Label
    Friend WithEvents lblNet As System.Windows.Forms.Label
    Friend WithEvents lblTaxResult As System.Windows.Forms.Label
    Friend WithEvents lblNetResult As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblTheName As System.Windows.Forms.Label
    Friend WithEvents lblNameResult As System.Windows.Forms.Label

End Class
