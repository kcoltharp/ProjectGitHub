﻿'Professor Carman
'Jellyfish Program
'2014
'This program allows the user to enter the amount of adult and youth jellyfish they would like to
'purchase.  Once entered, the calculations of cost for the adult, youth and total jellyfish are
'output to the screen.  The user also has the option to clear or exit the program

Option Strict On

Public Class frmJellyfish

    'Declaration of constants for prices
    Const cnumAdultPrice As Decimal = 25
    Const cnumYouthPrice As Decimal = 15

    Private Sub frmJellyfish_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'This event occurs when the program starts, as will clear the three result labels
        lblAdultCost.Text = ""
        lblYouthCost.Text = ""
        lblTotalCost.Text = ""
        'This will place the cursor in the first text box
        txtAdult.Focus()
    End Sub


    Private Sub btnCalculate_Click(sender As System.Object, e As System.EventArgs) Handles btnCalculate.Click
        'This button will gather input from the text boxes, perform calculations and output the results
        'in the appropriate labels
        'Declaration of variables
        Dim strAdultInput As String
        Dim numAdultInput As Decimal
        Dim strYouthInput As String
        Dim numYouthInput As Decimal
        Dim numAdultCost As Decimal
        Dim numYouthCost As Decimal
        Dim numTotalCost As Decimal


        'This area will take the input from the text box and convert to decimal
        strAdultInput = txtAdult.Text
        numAdultInput = Convert.ToDecimal(strAdultInput)
        strYouthInput = txtYouth.Text
        numYouthInput = Convert.ToDecimal(strYouthInput)

        'This are will perform the requisite calculations
        numAdultCost = numAdultInput * cnumAdultPrice
        numYouthCost = numYouthInput * cnumYouthPrice
        numTotalCost = numAdultCost + numYouthCost

        'This are outputs to the labels
        lblAdultCost.Text = numAdultCost.ToString("C2")
        lblYouthCost.Text = numYouthCost.ToString("C2")
        lblTotalCost.Text = numTotalCost.ToString("C2")

    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        'This will clear all labels and text boxes used by the program
        lblAdultCost.Text = ""
        lblYouthCost.Text = ""
        lblTotalCost.Text = ""
        txtAdult.Clear()
        txtYouth.Clear()
        'This will place the cursor in the first text box
        txtAdult.Focus()
    End Sub

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        'This will cause the program to exit
        Close()
    End Sub
End Class