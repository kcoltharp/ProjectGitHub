﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmJellyfish
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmJellyfish))
        Me.picJelly = New System.Windows.Forms.PictureBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.lblAdult = New System.Windows.Forms.Label()
        Me.lblYouth = New System.Windows.Forms.Label()
        Me.txtAdult = New System.Windows.Forms.TextBox()
        Me.txtYouth = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblCostLabelA = New System.Windows.Forms.Label()
        Me.lblCostLabelY = New System.Windows.Forms.Label()
        Me.lblCostLabelT = New System.Windows.Forms.Label()
        Me.lblAdultCost = New System.Windows.Forms.Label()
        Me.lblYouthCost = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        CType(Me.picJelly, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picJelly
        '
        Me.picJelly.Image = CType(resources.GetObject("picJelly.Image"), System.Drawing.Image)
        Me.picJelly.Location = New System.Drawing.Point(37, 28)
        Me.picJelly.Name = "picJelly"
        Me.picJelly.Size = New System.Drawing.Size(222, 167)
        Me.picJelly.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picJelly.TabIndex = 0
        Me.picJelly.TabStop = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(303, 77)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(335, 20)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "How many jellyfish would you like to purchase?"
        '
        'lblInstruction
        '
        Me.lblInstruction.AutoSize = True
        Me.lblInstruction.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstruction.Location = New System.Drawing.Point(307, 131)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(327, 48)
        Me.lblInstruction.TabIndex = 2
        Me.lblInstruction.Text = "Select the number of each type below, enter 0 for none" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Press the calculate butto" & _
    "n to calculate total cost" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "You may also press clear to start again, or exit to e" & _
    "xit"
        Me.lblInstruction.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAdult
        '
        Me.lblAdult.AutoSize = True
        Me.lblAdult.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdult.Location = New System.Drawing.Point(202, 244)
        Me.lblAdult.Name = "lblAdult"
        Me.lblAdult.Size = New System.Drawing.Size(122, 20)
        Me.lblAdult.TabIndex = 3
        Me.lblAdult.Text = "Adult  $25 Each"
        '
        'lblYouth
        '
        Me.lblYouth.AutoSize = True
        Me.lblYouth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYouth.Location = New System.Drawing.Point(202, 301)
        Me.lblYouth.Name = "lblYouth"
        Me.lblYouth.Size = New System.Drawing.Size(128, 20)
        Me.lblYouth.TabIndex = 4
        Me.lblYouth.Text = "Youth  $15 Each"
        '
        'txtAdult
        '
        Me.txtAdult.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAdult.Location = New System.Drawing.Point(394, 238)
        Me.txtAdult.Name = "txtAdult"
        Me.txtAdult.Size = New System.Drawing.Size(100, 26)
        Me.txtAdult.TabIndex = 5
        '
        'txtYouth
        '
        Me.txtYouth.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtYouth.Location = New System.Drawing.Point(394, 298)
        Me.txtYouth.Name = "txtYouth"
        Me.txtYouth.Size = New System.Drawing.Size(100, 26)
        Me.txtYouth.TabIndex = 6
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(124, 349)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(97, 36)
        Me.btnCalculate.TabIndex = 7
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(300, 349)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(97, 36)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(476, 349)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(97, 36)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblCostLabelA
        '
        Me.lblCostLabelA.AutoSize = True
        Me.lblCostLabelA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostLabelA.Location = New System.Drawing.Point(238, 417)
        Me.lblCostLabelA.Name = "lblCostLabelA"
        Me.lblCostLabelA.Size = New System.Drawing.Size(122, 20)
        Me.lblCostLabelA.TabIndex = 10
        Me.lblCostLabelA.Text = "Total Adult Cost"
        '
        'lblCostLabelY
        '
        Me.lblCostLabelY.AutoSize = True
        Me.lblCostLabelY.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostLabelY.Location = New System.Drawing.Point(238, 454)
        Me.lblCostLabelY.Name = "lblCostLabelY"
        Me.lblCostLabelY.Size = New System.Drawing.Size(128, 20)
        Me.lblCostLabelY.TabIndex = 11
        Me.lblCostLabelY.Text = "Total Youth Cost"
        '
        'lblCostLabelT
        '
        Me.lblCostLabelT.AutoSize = True
        Me.lblCostLabelT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostLabelT.Location = New System.Drawing.Point(238, 491)
        Me.lblCostLabelT.Name = "lblCostLabelT"
        Me.lblCostLabelT.Size = New System.Drawing.Size(81, 20)
        Me.lblCostLabelT.TabIndex = 12
        Me.lblCostLabelT.Text = "Total Cost"
        '
        'lblAdultCost
        '
        Me.lblAdultCost.AutoSize = True
        Me.lblAdultCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAdultCost.Location = New System.Drawing.Point(395, 417)
        Me.lblAdultCost.Name = "lblAdultCost"
        Me.lblAdultCost.Size = New System.Drawing.Size(63, 20)
        Me.lblAdultCost.TabIndex = 13
        Me.lblAdultCost.Text = "888888"
        '
        'lblYouthCost
        '
        Me.lblYouthCost.AutoSize = True
        Me.lblYouthCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYouthCost.Location = New System.Drawing.Point(395, 454)
        Me.lblYouthCost.Name = "lblYouthCost"
        Me.lblYouthCost.Size = New System.Drawing.Size(63, 20)
        Me.lblYouthCost.TabIndex = 14
        Me.lblYouthCost.Text = "888888"
        '
        'lblTotalCost
        '
        Me.lblTotalCost.AutoSize = True
        Me.lblTotalCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalCost.Location = New System.Drawing.Point(395, 491)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(63, 20)
        Me.lblTotalCost.TabIndex = 15
        Me.lblTotalCost.Text = "888888"
        '
        'frmJellyfish
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(697, 543)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblYouthCost)
        Me.Controls.Add(Me.lblAdultCost)
        Me.Controls.Add(Me.lblCostLabelT)
        Me.Controls.Add(Me.lblCostLabelY)
        Me.Controls.Add(Me.lblCostLabelA)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtYouth)
        Me.Controls.Add(Me.txtAdult)
        Me.Controls.Add(Me.lblYouth)
        Me.Controls.Add(Me.lblAdult)
        Me.Controls.Add(Me.lblInstruction)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.picJelly)
        Me.Name = "frmJellyfish"
        Me.Text = "frmJellyfish"
        CType(Me.picJelly, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picJelly As System.Windows.Forms.PictureBox
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblInstruction As System.Windows.Forms.Label
    Friend WithEvents lblAdult As System.Windows.Forms.Label
    Friend WithEvents lblYouth As System.Windows.Forms.Label
    Friend WithEvents txtAdult As System.Windows.Forms.TextBox
    Friend WithEvents txtYouth As System.Windows.Forms.TextBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblCostLabelA As System.Windows.Forms.Label
    Friend WithEvents lblCostLabelY As System.Windows.Forms.Label
    Friend WithEvents lblCostLabelT As System.Windows.Forms.Label
    Friend WithEvents lblAdultCost As System.Windows.Forms.Label
    Friend WithEvents lblYouthCost As System.Windows.Forms.Label
    Friend WithEvents lblTotalCost As System.Windows.Forms.Label

End Class
