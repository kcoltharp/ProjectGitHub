﻿'Professor Carman
'Chapter 4 example
'2-10-14
'This program shall allow the use to enter the number of koalas they desire.  then the total cost
'of the koalas shall be displayed.  The user will eventually be able to clear the information
'and enter a new number of koalas.  They will also be able to exit the program

Option Strict On

Public Class Form1

    'This is where I declare my constants
    Const cnumPricePerKoala As Decimal = 999

    Private Sub btnCalculate_Click(sender As System.Object, e As System.EventArgs) Handles btnCalculate.Click
        'This button will perform the calculation to give the total price for koalas
        Dim strNumberKoalas As String
        Dim numNumberKoalas As Integer
        Dim numTotalKoalaPrice As Decimal

        strNumberKoalas = txtKoalas.Text
        numNumberKoalas = Convert.ToInt32(strNumberKoalas)

        numTotalKoalaPrice = numNumberKoalas * cnumPricePerKoala

        lblResult.Text = numTotalKoalaPrice.ToString("C")

    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        'This button will clear the text box and the label.  This will also put the cursor back
        'into the text box
        txtKoalas.Clear()
        lblResult.Text = ""
        txtKoalas.Focus()
    End Sub

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        'This will close the program.  Thank you for playing have a nice day.
        Close()
    End Sub
End Class
