$(document).ready(function() {
		
	$("section > h1").css('font-size','42px');
	
	$("article > h1").css('font-size','24px');
	
});