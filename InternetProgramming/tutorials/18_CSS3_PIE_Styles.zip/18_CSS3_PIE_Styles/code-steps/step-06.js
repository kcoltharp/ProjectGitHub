<script src="/css3pie/PIE.js"></script>

$(function(){
	
	if ($('.post-DOM-element').length) {
		$('.post-DOM-element').each(function() {
			PIE.attach(this);
		});
	}

});
