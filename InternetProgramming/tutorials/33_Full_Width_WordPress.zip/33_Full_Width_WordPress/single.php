<?php get_header(); ?>

	<div id="content" class="widecolumn <?php if ( get_post_meta($post->ID, 'sidebar', true) == 1 ): echo 'nosidebar'; endif; ?>">
		<?php
			// Look for loop-single.php, fallback to loop.php
			get_template_part( 'loop', 'single' );
		?>
	</div>

<?php 
	// Is sidebar NOT set to Off we'll output it, otherwise not
	$custom_field = get_post_meta($post->ID, 'sidebar', true);
    	$other_value = "1";
	    if ($custom_field != $other_value) {
			get_sidebar();
	    } 
?>

<?php get_footer(); ?>