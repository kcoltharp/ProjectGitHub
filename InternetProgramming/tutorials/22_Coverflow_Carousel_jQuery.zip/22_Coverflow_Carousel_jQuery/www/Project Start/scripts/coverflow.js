		
		/*
		
		##########################
		COVERFLOW JQUERY TUTORIAL
		--------------------------
		Web Designer Magazine #189
		##########################
		
		*/
		
		containerwidth = 960;
		itemwidth = 400;
		
		$(document).ready(function(){
			
			// The document has loaded and is ready for us to start interacting with the DOM

			// We'll use a timer to prevent the coverflow effect from being too sensitive		
			var timer = 0;
		
			$(".coverflow").mousemove(function(e){
				// Respond to mouse movement
			});
			
			// Support for keyboard navigation using the tab key
			$(".coverflow ul li a").focus(function(){
				// Respond to normal keyboard input
			});
			
			$(document).keydown(function(e){
				// Add support for specific keys (the cursor keys in this case)
				
			});

			// Set the document into an initial state by calling one of focus, mousemove or keydown
			$(document).keydown();
			
			
			
			// Automatically update the position of the selected object to be central	
			//t = setInterval("centreit()",500);
			
		});
		
		// This function centres the selected object within the coverflow area
		function centreit(){
			$(".coverflow").each(function(){
				offsetleft = $(".current",this).offset().left;
				containeroffset = $(this).offset().left;
				offsetleft = offsetleft-containeroffset;
				target = (containerwidth/2)-(itemwidth/2);
				existingmargin = parseInt($("ul",this).css("marginLeft"));
				newmargin = existingmargin-(offsetleft-target);
				$("ul",this).stop().clearQueue().animate({marginLeft:newmargin},500);		
			});
		}