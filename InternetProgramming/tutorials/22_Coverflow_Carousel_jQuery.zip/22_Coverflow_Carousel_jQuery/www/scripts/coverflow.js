		
		/*
		
		##########################
		COVERFLOW JQUERY TUTORIAL
		--------------------------
		Web Designer Magazine #189
		--------------------------
		Author:	Sam Hampton-Smith
		##########################
		
		*/
		
		containerwidth = 960;
		itemwidth = 400;
		
		$(document).ready(function(){
			
			// The document has loaded and is ready for us to start interacting with the DOM

			// We'll use a timer to prevent the coverflow effect from being too sensitive		
			var timer = 0;
			
			$(".coverflow").mousemove(function(e){
				xpos = e.pageX-$(this).offset().left;
				index = $(".coverflow ul li").index($(".current"));
				length = $(".coverflow ul li").length-1;				
				if (xpos<((containerwidth-itemwidth)/2) && index>0 && timer==0) {
					index = index-1;
					timer = 1;
					resettimer = setTimeout(function(){timer=0;},1000);
				}
				if (xpos>((containerwidth-itemwidth)/2+itemwidth) && index<length && timer==0) {
					index = index+1;
					timer = 1;	
					resettimer = setTimeout(function(){timer=0;},1000);				
				}
				$(".coverflow ul li:eq("+index+")").prevAll("li").removeClass("current").removeClass("right").addClass("left");
				$(".coverflow ul li:eq("+index+")").nextAll("li").removeClass("current").removeClass("left").addClass("right");
				$(".coverflow ul li:eq("+index+")").removeClass("left").removeClass("right").addClass("current");
				$(".coverflow ul li:lt("+index+")").each(function(){
					tmpindex = $(".coverflow ul li").index(this);
					$(this).css({zIndex:tmpindex});
				});
				$(".coverflow ul li:gt("+index+")").each(function(){
					tmpindex = $(".coverflow ul li").index(this);
					$(this).css({zIndex:100-tmpindex});
				});
				$(".coverflow ul li:eq("+index+")").css({zIndex:1000}).focus();
			});
			
			// Support for keyboard navigation using the tab key
			$(".coverflow ul li a").focus(function(){
				index = $(".coverflow ul li").index($(this).parent("li"));
				$(".coverflow ul li:eq("+index+")").prevAll("li").removeClass("current").removeClass("right").addClass("left");
				$(".coverflow ul li:eq("+index+")").nextAll("li").removeClass("current").removeClass("left").addClass("right");
				$(".coverflow ul li:eq("+index+")").removeClass("left").removeClass("right").addClass("current");
				$(".coverflow ul li:lt("+index+")").each(function(){
					tmpindex = $(".coverflow ul li").index(this);
					$(this).css({zIndex:tmpindex});
				});
				$(".coverflow ul li:gt("+index+")").each(function(){
					tmpindex = $(".coverflow ul li").index(this);
					$(this).css({zIndex:100-tmpindex});
				});
				$(".coverflow ul li:eq("+index+")").css({zIndex:1000}).focus(); 
			});
			
			$(document).keydown(function(e){
				index = $(".coverflow ul li").index($(".current"));
				length = $(".coverflow ul li").length-1;
				// Left arrow
   				if (e.keyCode == 37) { 
					if (index>0) {
						index=index-1;
					}
    			}
				// Up arrow
				if (e.keyCode == 38) {
					index = 0;
				}
				// Right arrow (or tab key - be cautious doing this)
				if (e.keyCode == 39) { // || e.keyCode == 9) { 
       				if (index<length) {
						index=index+1;	
					}
    			}
				// Down arrow
				if (e.keyCode == 40) {
					index = length;
				}
				// Return key
				if (e.keyCode == 13) {
					// get the URL of the currently selected link
					url = $(".coverflow ul li:eq("+index+")").find("a").attr("href");
					// redirect to the URL grabbed
					document.location.href=url;					
				}
				$(".coverflow ul li:eq("+index+")").prevAll("li").removeClass("current").removeClass("right").addClass("left");
				$(".coverflow ul li:eq("+index+")").nextAll("li").removeClass("current").removeClass("left").addClass("right");
				$(".coverflow ul li:eq("+index+")").removeClass("left").removeClass("right").addClass("current");
				$(".coverflow ul li:lt("+index+")").each(function(){
					tmpindex = $(".coverflow ul li").index(this);
					$(this).css({zIndex:tmpindex});
				});
				$(".coverflow ul li:gt("+index+")").each(function(){
					tmpindex = $(".coverflow ul li").index(this);
					$(this).css({zIndex:100-tmpindex});
				});
				$(".coverflow ul li:eq("+index+")").css({zIndex:1000}).focus(); 
			});

			$(document).keydown();
			
			
			
			
			t = setInterval("centreit()",500);
			
		});
		
		function centreit(){
			$(".coverflow").each(function(){
				offsetleft = $(".current",this).offset().left;
				containeroffset = $(this).offset().left;
				offsetleft = offsetleft-containeroffset;
				target = (containerwidth/2)-(itemwidth/2);
				existingmargin = parseInt($("ul",this).css("marginLeft"));
				newmargin = existingmargin-(offsetleft-target);
				$("ul",this).stop().clearQueue().animate({marginLeft:newmargin},500);		
			});
		}