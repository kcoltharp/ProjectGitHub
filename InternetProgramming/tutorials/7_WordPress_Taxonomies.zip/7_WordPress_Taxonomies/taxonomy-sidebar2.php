<?php
/*
Plugin Name: Taxonomy Sidebar Menu
Plugin URI: http://localhost/
Description: Taxonomy Sidebar Menu
Author: Your Name
Version: 1
Author URI: http://localhost/
*/

function displayTaxonomy()
{
	echo'<li id="music-genres" class="widget-container">
  <h3 class="widget-title">Music Genres</h3>';
  $genres = get_terms('genre', 'hide_empty=1'); 
  echo '<ul>';
    foreach( $genres as $genre ) : 
      echo '<li>
        <a href="'. get_term_link( $genre->slug, 'brands' ). '">
          '.$genre->name.'
        </a>
        <ul>
          <?php
            $wpq = array( 'post_type' => 'cameras', 'taxonomy' => 'brands', 'term' => $brand->slug );
            $brand_posts = new WP_Query ($wpq);
          ?>
          <?php foreach( $brand_posts->posts as $post ) : ?>
            <li>
              <a href="<?php echo get_permalink( $post->ID ); ?>">
                <?php echo $post->post_title; ?>
              </a>
            </li>
          <?php endforeach ?>
        </ul>
      </li>
    <?php endforeach ?>
  </ul>
</li>