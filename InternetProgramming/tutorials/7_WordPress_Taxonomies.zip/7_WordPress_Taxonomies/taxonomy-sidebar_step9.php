<?php
/*
Plugin Name: Taxonomy Sidebar
Plugin URI: http://localhost/
Description: Taxonomy Sidebar Plugin
Author: Your Name
Version: 1
Author URI: http://localhost/
*/
 
