<?php
/*
Plugin Name: Taxonomy Sidebar
Plugin URI: http://localhost/
Description: Taxonomy Sidebar Plugin
Author: Your Name
Version: 1
Author URI: http://localhost/
*/
 
function displayTaxonomy()
{
  wp_tag_cloud( array( 'taxonomy' => 'genre', 'number' => 45 ) );
}
 
function widget_displayTaxonomy($args) {
  extract($args);
  echo $before_widget;
  echo $before_title;?>Taxonomies<?php echo $after_title;
  displayTaxonomy();
  echo $after_widget;
}
 