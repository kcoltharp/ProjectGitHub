<?php

	// Be sure to update the values below with your own settings
	// These will be provided by your host

	$host = "localhost"; 
	$username = "news";  
	$pass = "password";  
	$db = "newsletter"; 

	$myconnection = mysql_connect($host, $username,$pass) or die ("could not connect to mysql"); 
	mysql_select_db($db) or die ("Couldn't connect to the database");    

?>