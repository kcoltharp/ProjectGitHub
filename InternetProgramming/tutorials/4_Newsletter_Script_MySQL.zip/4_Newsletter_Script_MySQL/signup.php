<?php
	$name = "";
	$email = "";
	$completed = false;
	if ($_POST['name'] != "" && $_POST['email'] != "") {
		include_once "connect.php";
		
		// Clean the input to prevent SQL Injection attacks
		$name = cleaninput($_POST['name'],$myconnection);
		$email = cleaninput($_POST['email'],$myconnection);
	
		// Set up a variable for error messages - make it empty
		$feedback = '';
		
		if (!$email) {
			// No email address was provided 
			$feedback .= '<strong>Please enter your email address</strong><br />';
		}
		
		if (!$name) {
			// No name provided
			$feedback .= '<strong>Please enter your name</strong><br />';	
		}
	
		// Check email address is valid
	
		// First. we'll see if the domain is valid for email
		list($userName, $mailDomain) = split("@", $email); 
		if (!checkdnsrr($mailDomain, "MX")) { 
			// this email domain is not valid 
			$feedback .= '<strong>Invalid email domain</strong><br />';
		} 
	
		// Next we'll make sure the email address appears to be valid (i.e. it has an @ symbol, no invalid characters etc
		
		if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)) { 
			// This email address doesn't seem valid
			$feedback .= '<strong>Your email address doesn\'t appear to be valid - please check and try again';
		} 
	
		// We'll only run the following code if no errors were encountered
		if ($feedback=='') {
			$sql = mysql_query("SELECT * FROM subscribers WHERE email='$email'");
    		$numRows = mysql_num_rows($sql);
			if ($numRows>0) {
				// The email address provided is already in the database
				$feedback = '<strong>That email address is already subscribed.</strong>';
			} else {
				// Attempt to insert into the database
				$insertresult = mysql_query("INSERT INTO subscribers (name, email) VALUES('$name','$email')")  or die (mysql_error());
				
				// If insert was successful, mark the completed flag as true
				if ($insertresult) {
					$completed = true;	
				}
				
			}
		}
	}

// Show the form if the $completed flag is false

if ($completed==false) {

?>
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
		<fieldset> 
			<legend>Subscribe to Our Newsletter &nbsp;</legend> 
			<?php if ($feedback!='') echo('<p>'.$feedback.'</p>'); ?>
			<label>Name: <input name="name" type="text" value="<?php echo $name; ?>" /></label>
			<label>Email: <input name="email" type="text" value="<?php echo $email; ?>" /></label>
			<label><input type="submit" value="Sign Up!" /></label>
		</fieldset> 
	</form>
<?php 

} else {
	// Otherwise, show a thank you message

	echo('Thanks - you have been subscribed to our newsletter successfully. You can unsubscribe at any time by clicking on the link at the bottom of each email we send.');

}




	// This function attempts to loosely clean the input to prevent SQL injection attacks
	
	function cleaninput($value, $DB) {
		if (get_magic_quotes_gpc()) {
			$value = stripslashes( $value );
		}
		
		return mysql_real_escape_string( $value, $DB );
	}
?>