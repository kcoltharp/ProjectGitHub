/**
 * Adobe Helium: symbol definitions
 */
window.symbols = {
"stage": {
   version: "0.1",
   baseState: "Base State",
   initialState: "Base State",
   parameters: {

   },
   content: {
      dom: [
        {
            id:'Image1',
            type:'image',
            rect:[0,0,960,400],
            fill:['rgba(0,0,0,0)','images/bg.jpg'],
            transform:[],
        },
        {
            id:'Image2',
            type:'image',
            rect:[0,0,302,307],
            fill:['rgba(0,0,0,0)','images/logo.png'],
            transform:[[84,33]],
        },
        {
            id:'Text1',
            type:'text',
            rect:[485,163,541,77],
            text:"Adobe Edge Invasion",
            font:["Tahoma, Geneva, sans-serif",55,"rgba(0,0,0,1)","normal","none",""],
            transform:[[-90,-23]],
        },
        {
            id:'Text2',
            type:'text',
            rect:[635,244,304,30],
            text:"Animation for Desktop and Mobile",
            align:"auto",
            font:["Tahoma, Geneva, sans-serif",20,"rgba(255,255,255,1)","normal","none","normal"],
            transform:[[-28,-39]],
        },
        {
            id:'Image4',
            type:'image',
            rect:[0,0,282,79],
            fill:['rgba(0,0,0,0)','images/logo%2Dreflect.png'],
        },
      ],
      symbolInstances: [
      ],
   },
   states: {
      "Base State": {
         "#Image1": [
            ["style", "opacity", '0'],
            ["transform", "translateX", '0px'],
            ["transform", "translateY", '0px']
         ],
         "#stage": [
            ["color", "background-color", 'rgba(0,0,0,1)'],
            ["style", "width", '960px'],
            ["style", "height", '400px'],
            ["style", "overflow", 'hidden']
         ],
         "#Image2": [
            ["transform", "translateX", '-296px'],
            ["transform", "translateY", '33px'],
            ["transform", "rotateZ", '0deg']
         ],
         "#Image4": [
            ["transform", "translateX", '-296px'],
            ["transform", "translateY", '322px']
         ],
         "#Text2": [
            ["transform", "translateX", '-28px'],
            ["style", "font-size", '20px'],
            ["style", "height", '30px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '21px'],
            ["style", "width", '304px']
         ],
         "#Text1": [
            ["style", "font-size", '55px'],
            ["color", "color", 'rgba(255,255,255,1.00)'],
            ["transform", "translateX", '-10px'],
            ["style", "font-family", 'Tahoma, Geneva, sans-serif'],
            ["style", "height", '77px'],
            ["style", "opacity", '0'],
            ["transform", "translateY", '-23px'],
            ["style", "width", '541px']
         ]
      }
   },
   actions: {

   },
   bindings: [

   ],
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1750,
         timeline: [
            { id: "eid25", tween: [ "transform", "#Text2", "translateY", '-39px', { valueTemplate: undefined, fromValue: '21px'}], position: 1250, duration: 500, easing: "linear" },
            { id: "eid21", tween: [ "transform", "#Text1", "translateX", '-90px', { valueTemplate: undefined, fromValue: '-10px'}], position: 1000, duration: 500, easing: "linear" },
            { id: "eid11", tween: [ "transform", "#Image4", "translateX", '84px', { valueTemplate: undefined, fromValue: '-296px'}], position: 500, duration: 750, easing: "easeOutBack" },
            { id: "eid10", tween: [ "transform", "#Image4", "translateY", '322px', { valueTemplate: undefined, fromValue: '322px'}], position: 1250, duration: 0, easing: "linear" },
            { id: "eid4", tween: [ "style", "#Image1", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 0, duration: 1000, easing: "linear" },
            { id: "eid8", tween: [ "transform", "#Image2", "translateX", '84px', { valueTemplate: undefined, fromValue: '-296px'}], position: 500, duration: 750, easing: "easeOutBack" },
            { id: "eid23", tween: [ "style", "#Text2", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 1250, duration: 500, easing: "linear" },
            { id: "eid19", tween: [ "style", "#Text1", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 1000, duration: 500, easing: "linear" },
            { id: "eid12", tween: [ "transform", "#Image2", "rotateZ", '12deg', { valueTemplate: undefined, fromValue: '0deg'}], position: 500, duration: 420, easing: "linear" },
            { id: "eid13", tween: [ "transform", "#Image2", "rotateZ", '0deg', { valueTemplate: undefined, fromValue: '12deg'}], position: 920, duration: 330, easing: "linear" }]
      }
   },
}};

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     $.Edge.initialize(symbols);
});
/**
 * Adobe Edge Timeline Launch
 */
$(window).load(function() {
    $.Edge.play();
});
