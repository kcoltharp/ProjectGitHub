/**
 * Adobe Helium: symbol definitions
 */
window.symbols = {
"stage": {
   version: "0.1",
   baseState: "Base State",
   initialState: "Base State",
   parameters: {

   },
   content: {
      dom: [
      ],
      symbolInstances: [
      ],
   },
   states: {
      "Base State": {
         "#wrapper > header:nth-child(1)": [
            ["transform", "translateX", '0'],
            ["transform", "translateY", '-130px']
         ],
         "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(2) > a:nth-child(1)": [
            ["transform", "translateX", '90px'],
            ["style", "opacity", '0']
         ],
         "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(1) > a:nth-child(1)": [
            ["transform", "translateX", '90px'],
            ["style", "opacity", '0']
         ],
         "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(4) > a:nth-child(1)": [
            ["transform", "translateX", '90px'],
            ["style", "opacity", '0']
         ],
         "#hero": [
            ["style", "opacity", '0']
         ],
         "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(3) > a:nth-child(1)": [
            ["transform", "translateX", '90px'],
            ["style", "opacity", '0']
         ],
         "#content": [
            ["style", "opacity", '0']
         ]
      }
   },
   actions: {

   },
   bindings: [

   ],
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 2250,
         timeline: [
            { id: "eid23", tween: [ "transform", "#wrapper > header:nth-child(1)", "translateY", '0px', { valueTemplate: undefined, fromValue: '-130px'}], position: 0, duration: 750, easing: "linear" },
            { id: "eid25", tween: [ "style", "#hero", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 500, duration: 750, easing: "linear" },
            { id: "eid39", tween: [ "style", "#content", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 1750, duration: 500, easing: "linear" },
            { id: "eid37", tween: [ "transform", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(4) > a:nth-child(1)", "translateX", '0px', { valueTemplate: undefined, fromValue: '90px'}], position: 1500, duration: 500, easing: "linear" },
            { id: "eid36", tween: [ "style", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(4) > a:nth-child(1)", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 1500, duration: 500, easing: "linear" },
            { id: "eid35", tween: [ "transform", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(3) > a:nth-child(1)", "translateX", '0px', { valueTemplate: undefined, fromValue: '90px'}], position: 1250, duration: 500, easing: "linear" },
            { id: "eid32", tween: [ "style", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(2) > a:nth-child(1)", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 1000, duration: 500, easing: "linear" },
            { id: "eid34", tween: [ "style", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(3) > a:nth-child(1)", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 1250, duration: 500, easing: "linear" },
            { id: "eid27", tween: [ "style", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(1) > a:nth-child(1)", "opacity", '1', { valueTemplate: undefined, fromValue: '0'}], position: 750, duration: 500, easing: "linear" },
            { id: "eid19", tween: [ "transform", "#wrapper > header:nth-child(1)", "translateX", '0', { valueTemplate: undefined, fromValue: '0'}], position: 750, duration: 0, easing: "linear" },
            { id: "eid33", tween: [ "transform", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(2) > a:nth-child(1)", "translateX", '0px', { valueTemplate: undefined, fromValue: '90px'}], position: 1000, duration: 500, easing: "linear" },
            { id: "eid29", tween: [ "transform", "#wrapper > header:nth-child(1) > nav:nth-child(1) > ul:nth-child(1) > li:nth-child(1) > a:nth-child(1)", "translateX", '0px', { valueTemplate: undefined, fromValue: '90px'}], position: 750, duration: 500, easing: "linear" }]
      }
   },
}};

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     $.Edge.initialize(symbols);
});
/**
 * Adobe Edge Timeline Launch
 */
$(window).load(function() {
    $.Edge.play();
});
