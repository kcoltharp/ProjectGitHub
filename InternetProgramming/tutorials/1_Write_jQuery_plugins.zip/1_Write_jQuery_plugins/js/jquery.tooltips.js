(function($){
    
    $.fn.tooltips = function(options) {
        
        /*  default options for the tool tip that can be accessed and changed
         *  from outside 
        */
       var defaults = {
           
             speed: 200,                 // speed of tooltip animation                   
             rounded: true,              // CSS3 rounded corners set to false by default 
             hoverDelay: 200,            // For hover intent purposes
             mouseFollow: true           // follow the mouse pointer
            },
       
       //call in the defaults as options
       settings = $.extend({}, defaults, options);

       /* A function that builds the tooltip markup and then prepends
        * it to the body tag 
        */

       getTip = function() {
          var tTip = 
               "<div id='tooltip'>" + 
               "<div id='tipMid'>" +  
               "</div>" + 
               "<div id='tipBot'></div>" +
               "</div>";
           
          return tTip;       
       }

       $("body").prepend(getTip());
       
       /* give each item with an #id associated with the plugin
        * the ability to call the tooltip */
       
       $(this).each(function() {
           
           var defaults = options;
           var obj = $(this);
           var tip = $('#tooltip');
           var tipInner = $('#tooltip #tipMid');    
           obj.attr('tooltiptext',this.title);
           
           // removes the default browser tool tip
           this.title = '';

           // allows the ability to have CSS3 rounded corners when set to true
           if(defaults.rounded) {
               $('#tooltip').addClass('rounded');
           }
             
           // Mouse over function..
           obj.hover(function(){
                  tipInner.html($(this).attr('tooltiptext'));
                  setTip($(this));
                  setTimer()   
               },
               function() {
                    stopTimer();
                    tip.hide();         
               }
            );
             
              // finds the mouse location for tooltip to follow
              if(defaults.mouseFollow){
                obj.mousemove(function(e) {
                $('#tooltip').css({
                    top: e.pageY + -30,  
                    left: e.pageX + 30  
                   });
                });
              }
              
            // delay the fade-in animation of the tooltip
            setTimer = function(){                   
                obj.showTipTimer = setInterval(showTip, defaults.hoverDelay);
            }

            stopTimer = function() {
                clearInterval(obj.showTipTimer);
            }

            /* Position the tooltip relative to the class
               associated with the tooltip */
            setTip = function(obj) {

                // grabs the position of the hovered element and its height and width
                var offset  = obj.offset(),           
                    tLeft   = offset.left,
                    tTop    = offset.top,
                    tWidth  = obj.width(),
                    tHeight = obj.height(),
                    topOffset = tip.height(),
                    xTip = (tLeft+40)+"px",
                    yTip = (tTop-topOffset+20)+"px";
                    tip.css({'top' : yTip,  'left' : xTip});
                
            } // END setTip
            
            // Function that stops the timer, creates the animation and reveals the tip
            showTip = function() {
               stopTimer();
               tip.animate({"top": "-=10px", "opacity" : "toggle"}, defaults.speed)
            }    
       });
       
       return this; // returns the jQuery object to allow for chainability.
   
    } // end main function
    
})(jQuery);
