(function() {
    tinymce.create('tinymce.plugins.bitly_shorten', {
        init : function(ed, url) {
            ed.addButton('bitly_shorten', {
                title : 'Add the bit.ly URL shortcode',
                image : url+'/bitly_shortcode.png',
                onclick : function() {
                     ed.selection.setContent('[bitly_shorten]' + ed.selection.getContent() + '[/bitly_shorten]');

                }
            });
        },
        createControl : function(n, cm) {
            return null;
        },
    });
    tinymce.PluginManager.add('bitly_shorten', tinymce.plugins.bitly_shorten);
})();
