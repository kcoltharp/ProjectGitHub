<?php
/*
Plugin Name: bit.ly Shortcode Generator
Description: This plugin generates a bit.ly URL using a shortcode. For example: [bitly_shorten]http://yourlink.com[/bitly_shorten]
Version: 0.1
License: GPL
Author: Matt Gifford aka coldfumonkeh
Author URI: http://www.mattgifford.co.uk
*/


// add the filter to allow the shortcode to run in our widgets
add_filter('widget_text', 	'do_shortcode');

// Hook for adding admin menus
add_action('admin_menu', 	'createMenuItems');

// Function called by admin_menu hook
function createMenuItems() {
	// Add a new submenu under Settings:
	add_options_page('bitly shortcode', 'bitly shortcode', 'manage_options', 'bitly-settings', 'bitly_settings');
	// Create a new menu page specifically for this plugin
	add_menu_page('bitly shortcode', 	'bitly shortcode', 'manage_options', 'bitly-settings', 'bitly_settings');
}


// bitly settings function  - admin management page
function bitly_settings() {
    // Check that the user has the correct capability
    if (!current_user_can('manage_options'))
    {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }

    // Read in existing option value from database
    $bitly_username = get_option( 'bitly_username' );
	$bitly_apikey 	= get_option( 'bitly_apikey' );

    // See if the user has posted us some information
	// by checking the hidden field sent in the form.
    if( isset($_POST[ 'form_submit' ]) && $_POST[ 'form_submit' ] == 'Y' ) {
      
	    // Read the submitted value
		$bitly_username = $_POST['bitly_username'];
		$bitly_apikey 	= $_POST['bitly_apikey'];

        // Save the submitted value in the database
        update_option( 'bitly_username', 	$bitly_username );
		update_option( 'bitly_apikey', 		$bitly_apikey );
	

        // Put an settings updated message on the screen

		?>
			<div class="updated">
            	<p><strong><?php _e('Settings saved.', 'bitly_plugin' ); ?></strong></p>
            </div>
		<?php

    }

    // Now display the settings editing screen

    echo '<div class="wrap">';
	echo '<div class="icon32" id="icon-options-general"><br></div>';
    // header

    echo "<h2>" . __( 'bit.ly API Settings', 'bitly_plugin' ) . "</h2>";

    // settings form
    
    ?>

    <form name="form1" 		method="post" 		action="">
    <input type="hidden" 	name="form_submit" 	value="Y">
    
    <p><?php _e("bit.ly username:", 'bitly_plugin' ); ?> 
    <input type="text" name="bitly_username" value="<?php echo $bitly_username; ?>" size="20">
    </p>
    
    <p><?php _e("bit.ly api key:", 'bitly_plugin' ); ?> 
    <input type="text" name="bitly_apikey" value="<?php echo $bitly_apikey; ?>" size="20">
    </p><hr />
    
    <p class="submit">
    <input type="submit" name="Submit" class="button-primary" value="<?php esc_attr_e('Save Changes') ?>" />
    </p>
    
    </form>
    </div>

<?php
 
}


function getShortURL($atts, $content=null) {
		// Our chortcode attributes and default values
		extract(shortcode_atts(array(
			"target"		=> '_blank',
			"title"			=> 'Visit ' . $content . ' to see stuff.'
		), $atts));
		// Declare the bit.ly variables and values
		$apiUrl 	= 	'http://api.bitly.com/v3/shorten?';
		// Retrieve the options from the database		
		$username	=	get_option( 'bitly_username' );
		$apikey		=	get_option( 'bitly_apikey' );
		// Build the URL for the get request
		$strURL		=	$apiUrl . 'login=' . $username . '&apiKey=' . $apikey . '&longUrl=' . $content . '&format=json';
		// Run the get request
		$json 		= wp_remote_get($strURL);
		// get the array of data from the response
		$array 		= json_decode($json['body']);
		$shortURL 	= $array->data->url;
		// Build the HTML tag to return
		return '<a href="'. $shortURL .'" target="'. $target .'" title="'. $title .'">'. $shortURL .'</a>';
}

add_shortcode('bitly_shorten', 'getShortURL');

// button code
add_action('init', 'add_button');


function add_button() {
   if ( current_user_can('edit_posts') &&  current_user_can('edit_pages') )
   {
     add_filter('mce_external_plugins', 'add_bitly_plugin');
     add_filter('mce_buttons', 'register_button');
   }
}

function register_button($buttons) {
   array_push($buttons, "|", "bitly_shorten", "|");
   return $buttons;
}

function add_bitly_plugin($plugin_array) {
   $plugin_array['bitly_shorten'] = WP_PLUGIN_URL . '/bitly_shortcode/buttonAction.js';
   return $plugin_array;
}
// end of button code


?>