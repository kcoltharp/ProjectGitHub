<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="CSS/style.css" type="text/css" media="screen">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Facebook news feed</title>
</head>

<body>
<div id="wrapper">
<div class="container">
<div id="header"><img src="images/logo.png" /></div>
<div id="main">
	<div id="content">
    <h1>Latest News</h1>
<?php

//Set the page name or ID
$FBid = 'terrorfall';

//Get the contents of a Facebook page
$FBpage = file_get_contents('https://graph.facebook.com/'.$FBid.'/posts');

//Interpret data with JSON
$FBdata = json_decode($FBpage);

///Functions
//Convert URLs to links
function makeLink($string){

	$string = preg_replace("/([^\w\/])(www\.[a-z0-9\-]+\.[a-z0-9\-]+)/i", "$1http://$2",$string);
	$string = preg_replace("/([\w]+:\/\/[\w-?&;#~=\.\/\@]+[\w\/])/i","<a target=\"_blank\" href=\"$1\">$1</a>",$string);
	$string = preg_replace("/([\w-?&;#~=\.\/]+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?))/i","<a href=\"mailto:$1\">$1</a>",$string);

	return $string;
}

//Pretty time stamp
function timeSince($original) {
    // Array of time period
    $chunks = array(
        array(60 * 60 * 24 * 365 , 'year'),
        array(60 * 60 * 24 * 30 , 'month'),
        array(60 * 60 * 24 * 7, 'week'),
        array(60 * 60 * 24 , 'day'),
        array(60 * 60 , 'hour'),
        array(60 , 'minute'),
    );
    
	// Current time
    $today = time();   
    $since = $today - $original;
    
    // $j saves performing the count function each time around the loop
    for ($i = 0, $j = count($chunks); $i < $j; $i++) {
        
        $seconds = $chunks[$i][0];
        $name = $chunks[$i][1];
        
        // finding the biggest chunk (if the chunk fits, break)
        if (($count = floor($since / $seconds)) != 0) {
            break;
        }
    }
    
    $print = ($count == 1) ? '1 '.$name : "$count {$name}s";
    
    if ($i + 1 < $j) {
        // now getting the second item
        $seconds2 = $chunks[$i + 1][0];
        $name2 = $chunks[$i + 1][1];
        
        // add second item if it's greater than 0
        if (($count2 = floor(($since - ($seconds * $count)) / $seconds2)) != 0) {
            $print .= ($count2 == 1) ? ', 1 '.$name2 : ", $count2 {$name2}s";
        }
    }
    return $print;
}



//Loop through data for each news item
foreach ($FBdata->data as $news )
{
	echo '<div class="news-item">';
	echo '<h2>Posted '. $news->created_time . '</h2>';
	
	//Check for empty status (for example on shared link only)
	if (!empty($news->message)) { echo makeLink($news->message) . '<br />'; }
	
	//Check for 0 like data
	echo '<div style="float:right"><strong>Likes: '; 
		if (empty($news->likes->count)) { echo '0'; }  
		else { echo $news->likes->count; } 
	echo '</strong></div>';

	echo '<br /><hr /></div>';
}

?>
</div>
    <div id="sidebar">
    <h3>Become a fan on Facebook</h3>
    <script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script><fb:like-box href="http://www.facebook.com/terrorfall" width="292" show_faces="false" stream="false" header="true"></fb:like-box>
    </div>
    <div class="clear"></div>
</div>
</div>
<div id="footer">
	<div class="container"><a href="http://terrorfall.com" target="_blank">Built by Pete Simmons</a></div>
</div>
</div>
</body>
</html>